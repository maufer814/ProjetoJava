import java.util.ArrayList;
import java.util.Scanner;

public class Produto {
    protected int id;
    protected String nome;
    protected String descricao;
    protected double preco;
    protected int quantidade;

    private static ArrayList<Produto> listaProdutos = new ArrayList<>();

    public Produto(int id, String nome, String descricao, double preco, int quantidade) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    public static ArrayList<Produto> getListaProdutos() {
        return listaProdutos;
    }

    //retorna o valor do atributo id
    public int getId() {
        return id;
    }

    // Instânciando Produtos diretamente no ArrayList
    public static void inicializarProdutos() {
        listaProdutos.add(new Produto(1, "X-Burguer", "Pão, hambúrguer, queijo e molho", 12.50, 30));
        listaProdutos.add(new Produto(2, "X-Salada", "Pão, hambúrguer, queijo, alface e tomate", 13.90, 25));
        listaProdutos.add(new Produto(3, "X-Bacon", "Pão, hambúrguer, queijo e bacon", 10.00, 20));
        listaProdutos.add(new Produto(4, "Batata Frita P", "Porção pequena de batata frita", 6.00, 40));
        listaProdutos.add(new Produto(5, "Batata Frita G", "Porção grande de batata frita", 10.00, 30));
        listaProdutos.add(new Produto(6, "Refrigerante de Lata", "Lata 350ml (muitos sabores)", 4.00, 50));
        listaProdutos.add(new Produto(7, "Suco Natural", "Copo de suco natural 300ml", 7.00, 20));
        listaProdutos.add(new Produto(8, "Água Mineral", "Garrafa 500ml sem gás", 3.00, 60));
        listaProdutos.add(new Produto(9, "Milkshake", "Milkshake de chocolate ou morango", 9.90, 15));
        listaProdutos.add(new Produto(10, "Cachorro-Quente", "Pão com salsicha, molho e batata palha", 11.00, 18));
    }

        // Adicionar Produto
    public static void adicionarProduto(Scanner scanner) {
        System.out.print("ID do Produto: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Nome do Produto: ");
        String nome = scanner.nextLine();

        System.out.print("Descrição do Produto: ");
        String descricao = scanner.nextLine();

        System.out.print("Preço do Produto: ");
        double preco = scanner.nextDouble();

        System.out.print("Quantidade: ");
        int quantidade = scanner.nextInt();

        Produto novoProduto = new Produto(id, nome, descricao, preco, quantidade);
        listaProdutos.add(novoProduto);
        System.out.println("Produto adicionado com sucesso");
    }

        //Remover Produto//

    public static void removerProduto(Scanner scanner) {
        System.out.print("Informe o ID do produto a ser removido: ");
        int id = scanner.nextInt();
        boolean removido = false;

        for (Produto p : listaProdutos) {
            if (p.getId() == id) {
                listaProdutos.remove(p);
                System.out.println("Produto removido com sucesso");
                removido = true;
                break;
            }
        }
        //se não removido, id do prod nao encontrado
        if (!removido) {
            System.out.println("Produto com ID " + id + " nao encontrado.");
        }
    }


        // Listar Produtos //
    //lista os produtos, caso não tiver nenhum ele avisa
    public static void listarProdutos() {
        if (listaProdutos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
        } else {
            System.out.println("\n== Lista de Produtos ==");
            for (Produto p : listaProdutos) {
                System.out.println(p);
            }
        }
    }

    // Exibir dados
    @Override
    public String toString() {
        return "\nId: " + id +
                "\nNome: '" + nome + '\'' +
                "\nDescricao: '" + descricao + '\'' +
                "\nPreco: " + preco +
                "\nQuantidade: " + quantidade+
                "\n=========================================\n";

    }


    //Estatísticas dos Produtos
    public static void estatisticasProdutos() {
        ArrayList<Produto> produtos = Produto.getListaProdutos();

        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }

        Produto maisCaro = produtos.get(0);
        Produto maisBarato = produtos.get(0);
        double soma = 0;

        for (Produto p : produtos) {
            if (p.preco > maisCaro.preco) maisCaro = p;
            if (p.preco < maisBarato.preco) maisBarato = p;
            soma += p.preco;
        }

        double media = soma / produtos.size();
        int acimaDaMedia = 0;

        for (Produto p : produtos) {
            if (p.preco > media) acimaDaMedia++;
        }

        System.out.println("\n--- Estatísticas de Produtos ---");
        System.out.printf("Produto mais caro: %s (R$ %.2f)\n", maisCaro.nome, maisCaro.preco);
        System.out.printf("Produto mais barato: %s (R$ %.2f)\n", maisBarato.nome, maisBarato.preco);
        System.out.printf("Preço médio: R$ %.2f\n", media);
        System.out.println("Quantidade de produtos com preço acima da média: " + acimaDaMedia);
    }





    // MÉTODOS DE BUSCA//
    // Buscar Produto (por Descrição)
    public static void buscarProdutoporDescricao(Scanner scanner)
    {
        System.out.println("Digite parte da descrição do produto: ");
        String desc = scanner.nextLine();

        for (Produto p : Produto.getListaProdutos()) {
            if (p.descricao.toLowerCase().contains(desc.toLowerCase())) {
                System.out.println(p);
            }
        }
    }

    // Buscar Produto (por Código)
    public static void buscarProdutoPorCodigo(Scanner scanner) {
        System.out.print("Digite o ID do produto: ");
        int codigo = scanner.nextInt();
        scanner.nextLine(); // consumir a quebra de linha

        for (Produto p : Produto.getListaProdutos()) {
            if (p.id == codigo) {
                System.out.println(p);
                return;
            }
        }

        System.out.println("Produto não encontrado.");
    }


    // Buscar Produto (por Preço)
    public static void buscarProdutoPorPreco(Scanner scanner) {
        System.out.print("Digite o preço exato do produto: ");
        double preco = scanner.nextDouble();
        scanner.nextLine();

        for (Produto p : Produto.getListaProdutos()) {
            if (p.preco == preco) {
                System.out.println(p);
            }
        }
    }



    // GETs e SETs //
    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public static void setListaProdutos(ArrayList<Produto> listaProdutos) {
        Produto.listaProdutos = listaProdutos;
    }


}