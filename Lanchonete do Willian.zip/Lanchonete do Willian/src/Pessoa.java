import java.util.ArrayList;
import java.util.Scanner;

public abstract class Pessoa {
    protected String nome;
    protected double idade;
    protected String cpf;
    protected int cep;
    protected String endereco;


    public Pessoa(String nome, double idade, String cpf, int cep, String endereco) {
        this.nome = nome;
        this.idade = idade;
        this.cpf = cpf;
        this.cep = cep;
        this.endereco = endereco;
    }

    public abstract void exibir();


    // MÉTODOS DO MENU //

    // Adicionar Cliente
    public static void adicionarCliente(Scanner scanner, ArrayList<Pessoa> pessoas) {
        System.out.println("-- Cadastro de Cliente --");
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Idade: ");
        int idade = scanner.nextInt();
        scanner.nextLine();
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();
        System.out.print("CEP: ");
        int cep = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();

        pessoas.add(new Cliente(nome, idade, cpf, cep, endereco));
        System.out.println("Cliente adicionado com sucesso.");
    }


    // Adicionar Funcionário
    public static void adicionarFuncionario(Scanner scanner, ArrayList<Pessoa> pessoas) {
        System.out.println("-- Cadastro de Funcionário --");
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Idade: ");
        int idade = scanner.nextInt();
        scanner.nextLine();
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();
        System.out.print("CEP: ");
        int cep = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();
        System.out.print("Cargo: ");
        String cargo = scanner.nextLine();

        pessoas.add(new Funcionario(nome, idade, cpf, cep, endereco, cargo));
        System.out.println("Funcionário adicionado com sucesso.");
    }

    // Remover Pessoa (Cliente ou Funcionário)
    public static void removerPorCpf(Scanner scanner, ArrayList<Pessoa> pessoas) {
        System.out.print("Digite o CPF da pessoa a remover: ");
        String cpf = scanner.nextLine();
        boolean removido = false;

        for (int i = 0; i < pessoas.size(); i++) {
            if (pessoas.get(i).cpf.equals(cpf)) {
                pessoas.remove(i);
                removido = true;
                System.out.println("Pessoa removida com sucesso.");
                break;
            }
        }

        if (!removido) {
            System.out.println("Pessoa com CPF " + cpf + " não encontrada.");
        }
    }


    // Listar Pessoas (Clientes e Funcionários)
    public static void listarTodos(ArrayList<Pessoa> pessoas) {
        if (pessoas.isEmpty()) {
            System.out.println("Nenhuma pessoa cadastrada.");
        } else {
            for (Pessoa p : pessoas) {
                p.exibir();
            }
        }
    }

    // Estatísticas dos Clientes//
    public static void estatisticasClientes(ArrayList<Pessoa> pessoas) {
        ArrayList<Cliente> clientes = new ArrayList<>();

        for (Pessoa p : pessoas) {
            if (p instanceof Cliente) {
                clientes.add((Cliente) p);
            }
        }

        if (clientes.isEmpty()) {
            System.out.println("Nenhum cliente cadastrado.");
            return;
        }

        Cliente maisVelho = clientes.get(0);
        Cliente maisJovem = clientes.get(0);
        int maiores60 = 0;
        int menores18 = 0;
        int somaIdades = 0;

        for (Cliente c : clientes) {
            double idade = c.idade;

            if (idade > maisVelho.idade) maisVelho = c;
            if (idade < maisJovem.idade) maisJovem = c;

            if (idade > 60) maiores60++;
            if (idade < 18) menores18++;

            somaIdades += idade;
        }

        double media = (double) somaIdades / clientes.size();

        System.out.println("\n--- Estatísticas dos Clientes ---");
        System.out.println("Cliente mais velho: " + maisVelho.nome + " (" + maisVelho.idade + " anos)");
        System.out.println("Cliente mais jovem: " + maisJovem.nome + " (" + maisJovem.idade + " anos)");
        System.out.println("Quantidade de clientes maiores de 60 anos: " + maiores60);
        System.out.println("Quantidade de clientes menores de 18 anos: " + menores18);
        System.out.printf("Idade média dos clientes: %.2f anos\n", media);
    }





    // MÉTODOS DE BUSCA //

    // Buscar Cliente (por nome)
    public static void buscarCliente(Scanner scanner, ArrayList<Pessoa> pessoas)
    {
        System.out.println("Digite o nome do Cliente: ");
        String nomeParcial = scanner.nextLine();

        for(Pessoa p:pessoas){
            if(p instanceof Cliente && p.nome.toLowerCase().startsWith(nomeParcial.toLowerCase())){
                p.exibir();
            }
        }
    }

    // Buscar Funcionário (por Nome)
    public static void buscarFuncionario(Scanner scanner, ArrayList <Pessoa> pessoas)
    {
        System.out.println("Digite o nome do Funcionário: ");
        String nomeParcial = scanner.nextLine();

        for(Pessoa p:pessoas){
            if(p instanceof Funcionario && p.nome.toLowerCase().startsWith(nomeParcial.toLowerCase())){
                p.exibir();
            }
        }
    }




}
