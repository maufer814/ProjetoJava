import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<Pessoa> pessoas = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        Produto.inicializarProdutos(); //Instânciando os Produtos

        //Instânciando Clientes e Funcionários direto no ArrayList
        pessoas.add(new Cliente("Willian", 18, "294.469.498-74", 13607266, "Rua das Palmeiras, 601"));
        pessoas.add(new Funcionario("Maurício", 18, "59053266-4", 13607471, "Rua das Flores, 236", "Atendente"));
        pessoas.add(new Funcionario("Carlos", 18, "432.023.948-27", 13602879, "Av. Dona Renata, 541", "Atendente"));
        pessoas.add(new Funcionario("Carolina", 19, "187.254.396-15", 13600153, "Rua do Carpinteiro, 101", "Atendente"));
        pessoas.add(new Cliente("Frederico", 42, "546.325.744-29", 13607874, "Rua Adoniran Barbosa, 250"));
        pessoas.add(new Funcionario("Fernanda", 35, "874.164.953-14", 13602654, "Rua Zumbi dos Palmares, 541", "Gerente"));
        pessoas.add(new Funcionario("Paulo", 33, "624.248.329-54", 14578655, "Res. Lírio do Campo - Bloco J, apto 196", "Cozinheiro"));
        pessoas.add(new Cliente("Odair", 62, "951.357.846-50", 13602887, "Rua Tico Tico, 58"));
        pessoas.add(new Cliente("Vanda", 53, "265.715.314-99", 13605488, "Rua João Grilo, 727"));
        pessoas.add(new Cliente("Salmazo", 35, "123.321.222-11", 13605488, "Rua Mussum, 22"));


        // MENU PRINCIPAL //
        int opcao;
        System.out.println("\n=========LANCHONETE DO WILLIAN=========");
        do {
            System.out.println("\n========= MENU PRINCIPAL =========");
            System.out.println("1 - Gerenciar Pessoas (Clientes e Funcionários)");
            System.out.println("2 - Gerenciar Produtos");
            System.out.println("0 - Sair do Sistema");
            System.out.print("Digite a opção desejada: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    menuPessoas(scanner, pessoas);
                    break;
                case 2:
                    menuProdutos(scanner);
                    break;
                case 0:
                    System.out.println("Encerrando o sistema...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);

        scanner.close();
    }


        // MENU: GERENCIAR PESSOAS (Clientes e Funcionários) //
    public static void menuPessoas(Scanner scanner, ArrayList<Pessoa> pessoas) {
        int opcao;
        do {
            System.out.println("\n----- MENU DE PESSOAS -----");
            System.out.println("1 - Adicionar Cliente");
            System.out.println("2 - Adicionar Funcionário");
            System.out.println("3 - Remover Pessoa por CPF");
            System.out.println("4 - Listar Todas as Pessoas");
            System.out.println("5 - Ver Estatísticas dos Clientes");
            System.out.println("====================================");
            System.out.println("6 - Buscar Pessoas");
            System.out.println("0 - Voltar ao Menu Principal\n");
            System.out.print("Digite a opção desejada: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    Pessoa.adicionarCliente(scanner, pessoas);
                    break;
                case 2:
                    Pessoa.adicionarFuncionario(scanner, pessoas);
                    break;
                case 3:
                    Pessoa.removerPorCpf(scanner, pessoas);
                    break;
                case 4:
                    Pessoa.listarTodos(pessoas);
                    break;
                case 5:
                    Pessoa.estatisticasClientes(pessoas);
                    break;
                case 6:
                    System.out.println("1 - Buscar Cliente");
                    System.out.println("2 - Buscar Funcionário");

                    System.out.print("Digite a opção desejada: ");
                    opcao = scanner.nextInt();

                    scanner.nextLine(); // Limpar o buffer do teclado

                    if(opcao == 1)
                        Pessoa.buscarCliente(scanner, pessoas);
                    else if(opcao == 2)
                        Pessoa.buscarFuncionario(scanner, pessoas);

                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opção inválida");
            }
        } while (opcao != 0);
    }

    // MENU: GERENCIAR PRODUTOS //
    public static void menuProdutos(Scanner scanner) {
        int opcao;
        do {
            System.out.println("\n----- MENU DE PRODUTOS -----");
            System.out.println("1 - Adicionar Produto");
            System.out.println("2 - Remover Produto");
            System.out.println("3 - Listar Todos os Produtos");
            System.out.println("4 - Estatísticas dos Produtos");
            System.out.println("================================");
            System.out.println("5 - Buscar Produtos");
            System.out.println("0 - Voltar ao Menu Principal");
            System.out.print("Digite a opção desejada: ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            System.out.println("\n");

            switch (opcao) {
                case 1:
                    Produto.adicionarProduto(scanner);
                    break;
                case 2:
                    Produto.removerProduto(scanner);
                    break;
                case 3:
                    Produto.listarProdutos();
                    break;
                case 4:
                    Produto.estatisticasProdutos();
                    break;
                case 5:
                    System.out.println("1 - Buscar Produto por Descrição");
                    System.out.println("2 - Buscar Produto por Código");
                    System.out.println("3 - Buscar Produto por Preço");

                    System.out.print("Digite a opção desejada: ");
                    opcao = scanner.nextInt();
                    scanner.nextLine(); // Limpar o buffer do teclado

                    if(opcao == 1)
                        Produto.buscarProdutoporDescricao(scanner);
                    else if (opcao == 2)
                        Produto.buscarProdutoPorCodigo(scanner);
                    else if(opcao == 3)
                        Produto.buscarProdutoPorPreco(scanner);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }

}
