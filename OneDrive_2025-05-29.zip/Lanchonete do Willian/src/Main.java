import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<Pessoa> pessoas = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        Produto.inicializarProdutos(); //metodo pra inicializar os produtos

        // Dados iniciais de pessoas
        pessoas.add(new Cliente("Willian", 18, "294.469.498-74", 13607266, "Rua das Palmeiras, 601"));
        pessoas.add(new Funcionario("Maurício", 18, "59053266-4", 13607471, "Rua das Flores, 236", "Atendente"));
        pessoas.add(new Funcionario("Carlos", 18, "432.023.948-27", 13602879, "Av. Dona Renata, 541", "Atendente"));
        pessoas.add(new Funcionario("Maria", 19, "187.254.396-15", 13600153, "Rua do Carpinteiro, 101", "Atendente"));
        pessoas.add(new Cliente("Frederico", 42, "546.325.744-29", 13607874, "Rua Adoniran Barbosa, 250"));
        pessoas.add(new Funcionario("Fernanda", 35, "874.164.953-14", 13602654, "Rua Zumbi dos Palmares, 541", "Gerente"));
        pessoas.add(new Funcionario("Paulo", 33, "624.248.329-54", 14578655, "Res. Lírio do Campo - Bloco J, apto 196", "Cozinheiro"));
        pessoas.add(new Cliente("Odair", 62, "951.357.846-50", 13602887, "Rua Tico Tico, 58"));
        pessoas.add(new Cliente("Vanda", 53, "265.715.314-99", 13605488, "Rua João Grilo, 727"));
        pessoas.add(new Cliente("Salmazo", 35, "123.321.222-11", 13605488, "Rua Mussum, 22"));

        int opcao;

        //construcao do menu principal
        do {
            System.out.println("\n===== MENU PRINCIPAL =====");
            System.out.println("1. Cadastro de Pessoas (Clientes e Funcionários)");
            System.out.println("2. Cadastro de Produtos");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            //executa acoes conforme a opção digitada, repetindo até escolher sair.
            switch (opcao) {
                case 1:
                    menuPessoas(scanner, pessoas);
                    break;
                case 2:
                    menuProdutos(scanner);
                    break;
                case 0:
                    System.out.println("Encerrando o sistema...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);

        scanner.close();
    }

    // um submenu de pessoass
    public static void menuPessoas(Scanner scanner, ArrayList<Pessoa> pessoas) {
        int opcao;
        do {
            System.out.println("\n-- Menu de Pessoas --");
            System.out.println("1- Adicionar Cliente");
            System.out.println("2- Adicionar Funcionário");
            System.out.println("3- Remover Pessoa por CPF");
            System.out.println("4- Listar Todas as Pessoas");
            System.out.println("0- Voltar");
            System.out.print("Escolha: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            //mesma coisa que o primeiro switch
            switch (opcao) {
                case 1:
                    adicionarCliente(scanner, pessoas);
                    break;
                case 2:
                    adicionarFuncionario(scanner, pessoas);
                    break;
                case 3:
                    removerPorCpf(scanner, pessoas);
                    break;
                case 4:
                    listarTodos(pessoas);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opção inválida");
            }
        } while (opcao != 0);
    }

    // submenu de produtos
    public static void menuProdutos(Scanner scanner) {
        int opcao;
        do {
            System.out.println("\n-- Menu de Produtos --");
            System.out.println("1. Adicionar Produto");
            System.out.println("2. Remover Produto");
            System.out.println("3. Listar Produtos");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

        //mesma coisa que o primeiro switch
            switch (opcao) {
                case 1:
                    Produto.adicionarProduto(scanner);
                    break;
                case 2:
                    Produto.removerProduto(scanner);
                    break;
                case 3:
                    Produto.listarProdutos();
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
    //para adicionar cliente, uso básico do scanner
    public static void adicionarCliente(Scanner scanner, ArrayList<Pessoa> pessoas) {
        System.out.println("-- Cadastro de Cliente --");
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Idade: ");
        int idade = scanner.nextInt();
        scanner.nextLine();
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();
        System.out.print("CEP: ");
        int cep = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();

        pessoas.add(new Cliente(nome, idade, cpf, cep, endereco));
        System.out.println("Cliente adicionado com sucesso.");
    }
    //adiciona funcionario
    public static void adicionarFuncionario(Scanner scanner, ArrayList<Pessoa> pessoas) {
        System.out.println("-- Cadastro de Funcionário --");
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Idade: ");
        int idade = scanner.nextInt();
        scanner.nextLine();
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();
        System.out.print("CEP: ");
        int cep = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();
        System.out.print("Cargo: ");
        String cargo = scanner.nextLine();

        pessoas.add(new Funcionario(nome, idade, cpf, cep, endereco, cargo));
        System.out.println("Funcionário adicionado com sucesso.");
    }

    //remove por cpf, essa parte eu nao entendi muito e foi feito pelo chatgpt, depois em aula tentaremos entender
    public static void removerPorCpf(Scanner scanner, ArrayList<Pessoa> pessoas) {
        System.out.print("Digite o CPF da pessoa a remover: ");
        String cpf = scanner.nextLine();
        boolean removido = false;

        for (int i = 0; i < pessoas.size(); i++) {
            if (pessoas.get(i).cpf.equals(cpf)) {
                pessoas.remove(i);
                removido = true;
                System.out.println("Pessoa removida com sucesso.");
                break;
            }
        }

        if (!removido) {
            System.out.println("Pessoa com CPF " + cpf + " não encontrada.");
        }
    }
    //lista todos as pessoas, e se nenhuma estiver cadastrada exibe mensagem
    public static void listarTodos(ArrayList<Pessoa> pessoas) {
        if (pessoas.isEmpty()) {
            System.out.println("Nenhuma pessoa cadastrada.");
        } else {
            for (Pessoa p : pessoas) {
                p.exibir();
            }
        }
    }
}
